import { createBrowserRouter } from "react-router";
import { AboutPage } from "./components/AboutPage";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: AboutPage,
  },
]);
