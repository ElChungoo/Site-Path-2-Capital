import { motion } from 'motion/react';

const words = ["Strategy", "Growth", "Investment", "Vision", "Excellence", "Global", "M&A", "Capital"];

export function Marquee() {
  return (
    <div className="relative w-full overflow-hidden bg-accent text-black py-6 md:py-8 flex items-center z-10">
      <motion.div
        className="flex whitespace-nowrap"
        animate={{ x: ["0%", "-33.3333%"] }}
        transition={{ ease: "linear", duration: 20, repeat: Infinity }}
      >
        <div className="flex gap-8 md:gap-16 px-4 md:px-8">
          {[...words, ...words, ...words].map((word, i) => (
            <span key={i} className="text-3xl md:text-5xl lg:text-7xl font-bold uppercase tracking-tighter mix-blend-difference opacity-80">
              {word} •
            </span>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
