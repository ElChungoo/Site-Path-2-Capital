import { motion, useInView } from 'motion/react';
import { useRef } from 'react';

const stats = [
  {
    title: "$5B+",
    subtitle: "Capital Managed",
    desc: "Overseeing multi-billion dollar transactions and transformative capital allocations across key global markets.",
    span: "col-span-1 md:col-span-2 row-span-2",
  },
  {
    title: "15+",
    subtitle: "Years of Excellence",
    desc: "Consistently delivering tier-one advisory since our inception.",
    span: "col-span-1",
  },
  {
    title: "80%",
    subtitle: "Cross-Border Deals",
    desc: "Seamlessly connecting international markets to unlock hidden value.",
    span: "col-span-1",
  },
  {
    title: "120+",
    subtitle: "Successful M&A",
    desc: "Structuring acquisitions, mergers, and divestitures with an unblemished track record.",
    span: "col-span-1 md:col-span-2",
  }
];

export function Metrics() {
  const container = useRef(null);
  const isInView = useInView(container, { once: true, margin: "-100px" });

  return (
    <section className="relative py-32 px-6 md:px-12 bg-[#050505]">
      <div className="max-w-[90rem] mx-auto relative" style={{ position: 'relative' }} ref={container}>
        
        <div className="mb-20 flex flex-col md:flex-row justify-between items-end gap-8 border-b border-white/10 pb-12">
          <h2 className="text-4xl md:text-6xl font-semibold tracking-tighter uppercase">
            Quantifiable <br /><span className="text-accent">Impact</span>
          </h2>
          <p className="text-neutral-400 max-w-sm text-lg font-light">
            Our numbers reflect a legacy of relentless execution and uncompromising focus on long-term shareholder value.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 auto-rows-[250px]">
          {stats.map((stat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
              transition={{ duration: 0.8, delay: i * 0.1, ease: [0.76, 0, 0.24, 1] }}
              className={`group relative flex flex-col justify-between p-8 md:p-12 rounded-2xl bg-[#0a0a0a] border border-white/5 overflow-hidden transition-all duration-500 hover:border-accent hover:shadow-[0_0_40px_rgba(224,204,119,0.1)] ${stat.span}`}
            >
              {/* Subtle hover gradient background */}
              <div className="absolute inset-0 bg-gradient-to-br from-accent/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
              
              <div className="relative z-10">
                <h3 className="text-6xl md:text-8xl font-bold tracking-tighter text-white group-hover:text-accent transition-colors duration-500 mb-2">
                  {stat.title}
                </h3>
                <h4 className="text-xl md:text-2xl font-medium text-white mb-4 uppercase tracking-wide">
                  {stat.subtitle}
                </h4>
              </div>
              <p className="text-neutral-500 text-sm md:text-base max-w-sm relative z-10 group-hover:text-neutral-300 transition-colors duration-500">
                {stat.desc}
              </p>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
