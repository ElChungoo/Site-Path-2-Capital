import { ReactLenis } from '@studio-freight/react-lenis';
import { Hero } from './Hero';
import { Mission } from './Mission';
import { Metrics } from './Metrics';
import { Approach } from './Approach';
import { Team } from './Team';
import { Footer } from './Footer';
import { Marquee } from './Marquee';

export function AboutPage() {
  return (
    <ReactLenis root>
      <main style={{ position: 'relative' }} className="min-h-screen w-full bg-black text-white relative">
        <Hero />
        <Mission />
        <Metrics />
        <Marquee />
        <Approach />
        <Team />
        <Footer />
      </main>
    </ReactLenis>
  );
}
