import { motion, useScroll, useTransform } from 'motion/react';
import { useRef } from 'react';
import { ArrowRight } from 'lucide-react';
import logoImg from 'figma:asset/816f7cff5a7f4cabc11e09fc0ab1cf817456ead8.png';

export function Hero() {
  const container = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: container,
    offset: ['start start', 'end start'],
  });

  const y = useTransform(scrollYProgress, [0, 1], ['0vh', '50vh']);
  const opacity = useTransform(scrollYProgress, [0, 0.8], [1, 0]);

  return (
    <section 
      ref={container} 
      style={{ position: 'relative' }}
      className="relative h-screen w-full flex items-center justify-center overflow-hidden"
    >
      {/* Navigation Header */}
      <motion.header 
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 1, ease: [0.76, 0, 0.24, 1] }}
        className="absolute top-0 left-0 right-0 z-50 flex items-center justify-between px-6 md:px-12 py-6 w-full max-w-[90rem] mx-auto"
      >
        <div className="flex items-center gap-3 mix-blend-difference">
          <img src={logoImg} alt="Path 2 Capital Logo" className="h-10 w-10 object-contain" />
          <span className="font-bold text-lg md:text-xl uppercase tracking-widest text-white">Path 2 Capital</span>
        </div>
        <nav className="hidden md:flex items-center gap-8 text-sm uppercase tracking-widest font-semibold text-white mix-blend-difference">
          <a href="#about" className="hover:text-accent transition-colors cursor-pointer">About Us</a>
          <a href="#services" className="hover:text-accent transition-colors cursor-pointer">Services</a>
          <a href="#team" className="hover:text-accent transition-colors cursor-pointer">Team</a>
          <a href="#contact" className="hover:text-accent transition-colors cursor-pointer">Contact</a>
          <button className="bg-white text-black px-6 py-2.5 rounded-full hover:bg-accent transition-colors cursor-pointer">
            Get in touch
          </button>
        </nav>
      </motion.header>

      {/* Background Image Parallax */}
      <motion.div 
        style={{ y, opacity }}
        className="absolute inset-0 w-full h-full z-0"
      >
        <img 
          src="https://images.unsplash.com/photo-1760075999984-bbdea1f86b8d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW5zZSUyMG1ldHJvcG9saXMlMjBhZXJpYWwlMjBsb29raW5nJTIwZG93biUyMG5pZ2h0JTIwY2l0eSUyMHN0cmVldCUyMGxpZ2h0cyUyMGFyY2hpdGVjdHVyZXxlbnwxfHx8fDE3NzM0MjAwOTl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral" 
          alt="Dense metropolis aerial looking down night city street lights" 
          className="w-full h-full object-cover opacity-60"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-black/50 to-black"></div>
      </motion.div>

      <div className="relative z-10 w-full max-w-[90rem] mx-auto px-6 md:px-12 flex flex-col items-start justify-center">
        
        <div className="overflow-hidden mb-6">
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: '0%' }}
            transition={{ duration: 1, ease: [0.76, 0, 0.24, 1] }}
          >
            <p className="text-accent uppercase tracking-widest text-sm font-semibold mb-2">M&A Consultancy</p>
          </motion.div>
        </div>

        <h1 className="text-6xl md:text-8xl lg:text-9xl font-bold tracking-tighter leading-[0.9] text-white max-w-5xl uppercase mix-blend-difference">
          <span className="block overflow-hidden pb-2">
            <motion.span 
              initial={{ y: '100%' }} 
              animate={{ y: '0%' }} 
              transition={{ duration: 1, delay: 0.1, ease: [0.76, 0, 0.24, 1] }}
              className="block"
            >
              Driving
            </motion.span>
          </span>
          <span className="block overflow-hidden pb-2 text-transparent bg-clip-text" style={{ WebkitTextStroke: '2px #ffffff' }}>
            <motion.span 
              initial={{ y: '100%' }} 
              animate={{ y: '0%' }} 
              transition={{ duration: 1, delay: 0.2, ease: [0.76, 0, 0.24, 1] }}
              className="block"
            >
              Strategic
            </motion.span>
          </span>
          <span className="block overflow-hidden pb-2">
            <motion.span 
              initial={{ y: '100%' }} 
              animate={{ y: '0%' }} 
              transition={{ duration: 1, delay: 0.3, ease: [0.76, 0, 0.24, 1] }}
              className="block"
            >
              Growth.
            </motion.span>
          </span>
        </h1>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.6, ease: 'easeOut' }}
          className="mt-12 md:mt-16 flex flex-col md:flex-row items-start md:items-center gap-8 w-full max-w-3xl"
        >
          <p className="text-lg md:text-xl text-neutral-400 font-light flex-1 max-w-md">
            We partner with visionary leaders to engineer transformational mergers, 
            acquisitions, and sustainable market expansion.
          </p>
          
          <button className="group relative overflow-hidden rounded-full bg-accent px-8 py-4 flex items-center gap-3 text-black font-semibold uppercase tracking-wider text-sm transition-all hover:bg-white">
            <span className="relative z-10">Discover Our Process</span>
            <span className="relative z-10 transform group-hover:translate-x-1 transition-transform">
              <ArrowRight size={18} />
            </span>
          </button>
        </motion.div>
      </div>
    </section>
  );
}
