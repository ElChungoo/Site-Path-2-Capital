import { motion, useScroll, useTransform } from 'motion/react';
import { useRef } from 'react';

const text = "We exist to align ambition with executable strategy. True growth isn't just about the deal—it's about foreseeing what the market demands next and capturing it with unwavering precision.";

export function Mission() {
  const container = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: container,
    offset: ['start center', 'end center'],
  });

  const words = text.split(" ");

  return (
    <section 
      ref={container} 
      style={{ position: 'relative' }}
      className="relative min-h-[150vh] flex flex-col justify-center items-center py-32 px-6 md:px-12 bg-black"
    >
      <div className="sticky top-0 h-screen w-full flex items-center justify-center max-w-[90rem] mx-auto">
        <h2 className="text-4xl md:text-6xl lg:text-8xl font-medium tracking-tight leading-[1.1] text-left">
          {words.map((word, i) => {
            const start = i / words.length;
            const end = start + (1 / words.length);
            // We use standard scroll hook with transform to fade each word
            return (
              <Word key={i} progress={scrollYProgress} range={[start, end]} word={word} />
            )
          })}
        </h2>
      </div>
    </section>
  );
}

function Word({ word, progress, range }: { word: string, progress: any, range: number[] }) {
  const opacity = useTransform(progress, range, [0.1, 1]);
  const color = useTransform(progress, range, ['#333333', '#ffffff']);
  
  return (
    <span className="relative mr-4 lg:mr-6 inline-block">
      <motion.span style={{ opacity, color }} className="transition-colors duration-100 ease-linear">
        {word}
      </motion.span>
      {/* 
        Wait, Framer motion style={{ color }} transition colors smoothly without extra wrapper, 
        but we can also just use absolute black layer and a white layer with opacity changing. 
        Actually, we can just use the color transform above. 
      */}
    </span>
  );
}
