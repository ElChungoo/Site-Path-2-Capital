import { motion, useScroll, useTransform } from 'motion/react';
import { useRef, useState, useEffect } from 'react';

export function Footer() {
  const container = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: container,
    offset: ['start end', 'end end'],
  });

  const y = useTransform(scrollYProgress, [0, 1], ['-30%', '0%']);
  
  // Magnetic Button Effect
  const buttonRef = useRef<HTMLButtonElement>(null);
  const [position, setPosition] = useState({ x: 0, y: 0 });

  const handleMouseMove = (e: React.MouseEvent<HTMLButtonElement>) => {
    const { clientX, clientY } = e;
    if (!buttonRef.current) return;
    const { left, top, width, height } = buttonRef.current.getBoundingClientRect();
    const x = (clientX - (left + width / 2)) * 0.4;
    const y = (clientY - (top + height / 2)) * 0.4;
    setPosition({ x, y });
  };

  const handleMouseLeave = () => {
    setPosition({ x: 0, y: 0 });
  };

  return (
    <footer 
      ref={container}
      style={{ position: 'relative' }}
      className="relative h-screen bg-black overflow-hidden flex flex-col justify-end"
    >
      <motion.div 
        style={{ y }} 
        className="h-full w-full flex flex-col justify-between pt-32 pb-12 px-6 md:px-12 max-w-[90rem] mx-auto"
      >
        <div className="flex-1 flex flex-col justify-center items-center text-center">
          <h2 className="text-5xl md:text-8xl lg:text-[10rem] font-bold tracking-tighter leading-[0.85] uppercase mb-16 max-w-6xl">
            Let's close the <br /> <span className="text-transparent bg-clip-text text-white" style={{ WebkitTextStroke: '2px #e0cc77' }}>deal</span> together
          </h2>

          <motion.button
            ref={buttonRef}
            onMouseMove={handleMouseMove}
            onMouseLeave={handleMouseLeave}
            animate={{ x: position.x, y: position.y }}
            transition={{ type: "spring", stiffness: 150, damping: 15, mass: 0.1 }}
            className="relative w-40 h-40 md:w-56 md:h-56 rounded-full bg-accent flex items-center justify-center text-black font-bold uppercase tracking-widest text-sm md:text-lg hover:bg-white transition-colors duration-500 z-10"
          >
            Get In Touch
          </motion.button>
        </div>

        <div className="flex flex-col md:flex-row justify-between items-center text-neutral-500 text-sm tracking-wide gap-6 border-t border-white/10 pt-8 mt-16">
          <div className="flex gap-8 uppercase">
            <a href="#" className="hover:text-accent transition-colors">LinkedIn</a>
            <a href="#" className="hover:text-accent transition-colors">Twitter</a>
            <a href="#" className="hover:text-accent transition-colors">Insights</a>
          </div>
          <p>© {new Date().getFullYear()} M&A Consultancy. All rights reserved.</p>
        </div>
      </motion.div>
    </footer>
  );
}
