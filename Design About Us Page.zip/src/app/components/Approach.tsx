import { motion, useScroll, useTransform, useInView } from 'motion/react';
import { useRef, useState, useEffect } from 'react';

const steps = [
  {
    id: '01',
    title: "Mergers & Acquisitions",
    description: "Composed of Sale Advisory and Acquisition Advisory. We execute highly structured processes to maximize value in sell-side engagements, and identify, evaluate, and integrate optimal targets for buy-side mandates.",
  },
  {
    id: '02',
    title: "Capital Raising",
    description: "We orchestrate debt and equity capital raises to fuel strategic growth, optimize capital structures, and facilitate shareholder transitions by connecting you with top-tier institutional investors.",
  },
  {
    id: '03',
    title: "Strategic Advice",
    description: "Comprehensive advisory services tailored to your most critical corporate finance decisions. We provide unbiased, data-driven insights on valuations, market positioning, and long-term capital strategy.",
  },
];

const images = [
  "https://images.unsplash.com/photo-1758518727707-b023e285b709?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3Jwb3JhdGUlMjBidXNpbmVzcyUyMG1lZXRpbmclMjBtb2Rlcm4lMjBvZmZpY2V8ZW58MXx8fHwxNzczNDE2NDY1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  "https://images.unsplash.com/photo-1695067439031-f59068994fae?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBhcmNoaXRlY3R1cmUlMjBidWlsZGluZ3xlbnwxfHx8fDE3NzMzNjY4OTF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  "https://images.unsplash.com/photo-1671722294182-ed01cbe66bd1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkYXJrJTIwbHV4dXJ5JTIwb2ZmaWNlJTIwbWluaW1hbHxlbnwxfHx8fDE3NzM0MTY0NzJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
];

export function Approach() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [activeStep, setActiveStep] = useState(0);
  
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start start', 'end end']
  });
  
  useEffect(() => {
    return scrollYProgress.on("change", (latest) => {
      const stepIndex = Math.min(
        Math.floor(latest * 0.99 * steps.length),
        steps.length - 1
      );
      setActiveStep(stepIndex);
    });
  }, [scrollYProgress]);

  return (
    <section 
      ref={containerRef}
      style={{ position: 'relative' }}
      className="relative min-h-[300vh] bg-black text-white"
    >
      <div className="sticky top-0 h-screen w-full flex items-center overflow-hidden">
        <div className="w-full max-w-[90rem] mx-auto px-6 md:px-12 grid grid-cols-1 md:grid-cols-2 gap-12 md:gap-24 items-center h-full">
          
          {/* Left: Text Content */}
          <div className="relative h-full flex flex-col justify-center">
            <h2 className="text-4xl md:text-5xl font-bold tracking-tighter uppercase mb-16">
              OUR <span className="text-accent">SERVICES</span>
            </h2>

            <div className="relative h-[400px]">
              {steps.map((step, index) => {
                const isActive = activeStep === index;
                
                return (
                  <motion.div
                    key={step.id}
                    className="absolute inset-0 flex flex-col justify-start"
                    initial={{ opacity: 0, y: 50 }}
                    animate={{ 
                      opacity: isActive ? 1 : 0, 
                      y: isActive ? 0 : (index < activeStep ? -50 : 50),
                      pointerEvents: isActive ? 'auto' : 'none'
                    }}
                    transition={{ duration: 0.8, ease: [0.76, 0, 0.24, 1] }}
                  >
                    <div className="text-accent text-lg font-semibold mb-4 tracking-widest">
                      {step.id}
                    </div>
                    <h3 className="text-3xl md:text-5xl font-semibold tracking-tighter mb-6 leading-tight text-white">
                      {step.title}
                    </h3>
                    <p className="text-lg md:text-xl text-neutral-400 font-light leading-relaxed max-w-md">
                      {step.description}
                    </p>
                  </motion.div>
                );
              })}
            </div>
          </div>

          {/* Right: Images */}
          <div className="relative h-[60vh] md:h-[70vh] rounded-2xl overflow-hidden shadow-2xl bg-neutral-900 hidden md:block">
            {images.map((imgSrc, index) => {
              const isActive = activeStep === index;
              return (
                <motion.div
                  key={index}
                  className="absolute inset-0"
                  initial={{ opacity: 0, scale: 1.1 }}
                  animate={{ 
                    opacity: isActive ? 1 : 0,
                    scale: isActive ? 1 : 1.1,
                  }}
                  transition={{ duration: 1.2, ease: [0.76, 0, 0.24, 1] }}
                >
                  <img 
                    src={imgSrc} 
                    alt={`Approach phase ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/20 mix-blend-multiply" />
                </motion.div>
              );
            })}
          </div>

        </div>
      </div>
    </section>
  );
}
