import { motion, useInView } from 'motion/react';
import { useRef } from 'react';

const team = [
  {
    name: "Eleanor Vance",
    role: "Managing Partner",
    img: "https://images.unsplash.com/photo-1758599543120-4e462429a4d7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBjb3Jwb3JhdGUlMjBoZWFkc2hvdCUyMHdvbWFufGVufDF8fHx8MTc3MzMwNzU3MHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    name: "Marcus Sterling",
    role: "Head of Strategy",
    img: "https://images.unsplash.com/photo-1762522927402-f390672558d8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBjb3Jwb3JhdGUlMjBoZWFkc2hvdCUyMG1hbnxlbnwxfHx8fDE3NzM0MTY0NjV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    name: "Sarah Jenkins",
    role: "Director of M&A",
    img: "https://images.unsplash.com/photo-1689600944138-da3b150d9cb8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBidXNpbmVzcyUyMHdvbWFuJTIwaGVhZHNob3R8ZW58MXx8fHwxNzczMzM5OTE0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    name: "Jameson Clarke",
    role: "VP Corporate Development",
    img: "https://images.unsplash.com/photo-1723537742563-15c3d351dbf2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBidXNpbmVzcyUyMG1hbiUyMGhlYWRzaG90fGVufDF8fHx8MTc3MzM1MTAyMHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
];

export function Team() {
  const container = useRef(null);
  const isInView = useInView(container, { once: true, margin: "-100px" });

  return (
    <section className="py-32 px-6 md:px-12 bg-[#050505]">
      <div className="max-w-[90rem] mx-auto relative" style={{ position: 'relative' }} ref={container}>
        
        <div className="flex justify-between items-end mb-16">
          <h2 className="text-4xl md:text-6xl font-semibold tracking-tighter uppercase">
            The <span className="text-accent">Architects</span>
          </h2>
          <div className="hidden md:block w-32 h-[1px] bg-accent/50" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {team.map((member, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 40 }}
              transition={{ duration: 0.8, delay: i * 0.15, ease: [0.76, 0, 0.24, 1] }}
              className="group relative aspect-[3/4] overflow-hidden rounded-xl bg-neutral-900 cursor-pointer"
            >
              <motion.img 
                src={member.img}
                alt={member.name}
                className="w-full h-full object-cover transition-transform duration-700 ease-[0.76,0,0.24,1] group-hover:scale-105 filter grayscale-[0.2] group-hover:grayscale-0"
              />
              
              {/* Gradient Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent opacity-60 group-hover:opacity-80 transition-opacity duration-500" />
              
              {/* Text Reveal Container */}
              <div className="absolute inset-x-0 bottom-0 p-6 flex flex-col justify-end translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-500 ease-[0.76,0,0.24,1]">
                <h3 className="text-2xl font-bold tracking-tighter text-white mb-1">
                  {member.name}
                </h3>
                <p className="text-accent text-sm font-medium tracking-widest uppercase">
                  {member.role}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
